/* 实体表 */
CREATE TABLE `SalesRankingTemporary` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`proId` varchar(256) NULL COMMENT '货号',
`salesRanking` bigint(20) NULL COMMENT '当天排名',
PRIMARY KEY (`id`)
) COMMENT='销量排名导入表';


CREATE TABLE `ProSpecification` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`proID` bigint(20) NULL COMMENT '商品id',
`size1` varchar(256) NULL COMMENT '尺码1',
`size2` varchar(256) NULL COMMENT '尺码2',
`quantity` bigint(20) NULL COMMENT '数量',
`discount` decimal(31,3) NULL COMMENT '参考折扣',
`sellingPrice` decimal(31,3) NULL COMMENT '市场价',
`channel` varchar(256) NULL COMMENT '货源',
`supplyPrice` decimal(31,3) NULL COMMENT '供货价',
`selling` decimal(31,3) NULL COMMENT '售价',
`commodityCode` varchar(256) NULL COMMENT '商品编码',
PRIMARY KEY (`id`)
) COMMENT='商品规格';


CREATE TABLE `ProductTemporary` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`proNumber` varchar(256) NULL COMMENT '商品货号',
`channel` varchar(256) NULL COMMENT '货源',
`size1` varchar(256) NULL COMMENT '尺码1',
`size2` varchar(256) NULL COMMENT '尺码2',
`brand` varchar(256) NULL COMMENT '品牌',
`sellingPrice` decimal(31,3) NULL COMMENT '市场价',
`quantity` bigint(20) NULL COMMENT '库存数量',
`type` varchar(256) NULL COMMENT '类别',
`type2` varchar(256) NULL COMMENT '二级分类',
`type3` varchar(256) NULL COMMENT '三级分类',
`sex` varchar(256) NULL COMMENT '性别',
`season` varchar(256) NULL COMMENT '季节',
`discount` decimal(31,3) NULL COMMENT '参考折扣',
`salesRanking` bigint(20) NULL COMMENT '销量排名',
`proName` varchar(256) NULL COMMENT '商品名称',
PRIMARY KEY (`id`)
) COMMENT='商品';


CREATE TABLE `Product` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`productCode` varchar(256) NULL COMMENT '商品货号',
`brand` varchar(256) NULL COMMENT '品牌',
`sellingPrice` decimal(31,3) NULL COMMENT '市场价',
`quantity` bigint(20) NULL COMMENT '库存数量',
`type` varchar(256) NULL COMMENT '类别',
`type2` varchar(256) NULL COMMENT '二级分类',
`type3` varchar(256) NULL COMMENT '三级分类',
`sex` varchar(256) NULL COMMENT '性别',
`season` varchar(256) NULL COMMENT '季节',
`discount` decimal(31,3) NULL COMMENT '参考折扣',
`rate` bigint(20) NULL COMMENT '评级',
`salesRanking` bigint(20) NULL COMMENT '销量排名',
`proName` varchar(256) NULL COMMENT '商品名称',
PRIMARY KEY (`id`)
) COMMENT='商品';


CREATE TABLE `LCAPLogicViewMapping_5cda30` (
`id` bigint(20) NOT NULL COMMENT '主键',
`logicIdentifier` varchar(256) NOT NULL COMMENT '/api/logic1:GET',
`resourceName` varchar(256) NOT NULL COMMENT '/dashboard/button1',
`resourceType` varchar(256) NOT NULL COMMENT '页面-page 组件-component 逻辑-logic',
`group` bigint(20) NOT NULL COMMENT '值一样的为同一组',
`changeTime` bigint(20) NULL COMMENT '创建时间',
PRIMARY KEY (`id`)
) COMMENT='记录应用全局逻辑与页面资源的关联关系';


CREATE TABLE `LCAPUser_5cda30` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`userId` varchar(256) NOT NULL COMMENT '第三方登录方式唯一id；普通登录使用userName+source作为userId',
`userName` varchar(256) NOT NULL COMMENT '普通登录用户名，类似账号的概念',
`password` varchar(256) NULL COMMENT '普通登录密码，密码建议加密存储。第三方登录不会存储密码',
`phone` varchar(256) NULL COMMENT '手机号',
`email` varchar(256) NULL COMMENT '邮箱',
`displayName` varchar(256) NULL COMMENT '展示的名称',
`status` varchar(256) NULL DEFAULT 'Normal' COMMENT '状态，标识当前用户的状态是什么',
`source` varchar(256) NOT NULL DEFAULT 'Normal' COMMENT '当前条用户数据来自哪个用户源，如普通登录、微信登录',
PRIMARY KEY (`id`)
) COMMENT='制品应用的用户实体。
1 实体名称不允许改动
2 默认生成的字段不允许改动
3 可新增自定义字段（避免设置为非空且无默认值）';


CREATE TABLE `LCAPRolePerMapping_5cda30` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`roleId` bigint(20) NOT NULL COMMENT '角色唯一ID',
`permissionId` bigint(20) NOT NULL COMMENT '权限唯一ID',
PRIMARY KEY (`id`)
) COMMENT='角色权限关联实体。新增角色一般需要新增角色对应的权限。默认生成的字段不允许改动，可新增自定义字段。';


CREATE TABLE `LCAPPerResMapping_5cda30` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`permissionId` bigint(20) NOT NULL COMMENT '权限唯一ID',
`resourceId` bigint(20) NOT NULL COMMENT '资源唯一ID',
PRIMARY KEY (`id`)
) COMMENT='权限与资源的关联实体。一组权限会包含若干资源路径，权限对应角色。为角色绑定移除资源需操作该表。默认字段不允许改动，可新增字段。';


CREATE TABLE `LCAPUserRoleMapping_5cda30` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`userId` varchar(256) NOT NULL COMMENT '用户唯一ID',
`roleId` bigint(20) NOT NULL COMMENT '角色唯一ID',
`userName` varchar(256) NULL COMMENT '用户名',
`source` varchar(256) NULL COMMENT '用户来源',
PRIMARY KEY (`id`)
) COMMENT='用户与角色关联实体。操作该表可完成为角色添加成员、移除角色成员等。默认生成的字段不允许改动，可新增自定义字段。';


CREATE TABLE `LCAPRole_5cda30` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`uuid` varchar(256) NULL COMMENT '唯一标识',
`name` varchar(256) NOT NULL COMMENT '角色名',
`description` varchar(256) NULL COMMENT '角色描述',
`roleStatus` tinyint(1) NULL DEFAULT 1 COMMENT '角色状态，可配置true启用，false禁用。',
`editable` tinyint(1) NULL DEFAULT 1 COMMENT '系统字段，请勿修改。web新增为可编辑true，ide新增为不可编辑false。',
PRIMARY KEY (`id`)
) COMMENT='用户与角色关联实体。操作该表可完成为角色添加成员、移除角色成员等。默认生成的字段不允许改动，可新增自定义字段。';


CREATE TABLE `LCAPPermission_5cda30` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`uuid` varchar(256) NULL COMMENT '唯一标识',
`name` varchar(256) NOT NULL COMMENT '权限名称',
`description` varchar(256) NULL COMMENT '权限描述',
PRIMARY KEY (`id`)
) COMMENT='权限实体。新增角色的同时要一般需要绑定角色对应的权限。默认生成的字段不允许改动，可新增自定义字段。';


CREATE TABLE `LCAPResource_5cda30` (
`id` bigint(20) NOT NULL COMMENT '主键',
`createdTime` datetime NULL COMMENT '创建时间',
`updatedTime` datetime NULL COMMENT '更新时间',
`createdBy` varchar(256) NULL COMMENT '创建者',
`updatedBy` varchar(256) NULL COMMENT '更新者',
`uuid` varchar(256) NULL COMMENT '唯一标识',
`name` varchar(256) NOT NULL COMMENT '资源路径，如/test/api',
`description` varchar(256) NULL COMMENT '资源描述',
`type` varchar(256) NULL COMMENT '资源类型',
`clientType` varchar(256) NULL COMMENT '端标识',
PRIMARY KEY (`id`)
) COMMENT='资源实体。该表的数据是新建组件后，系统自动上报的。name字段对应资源路径。默认生成的字段不允许改动，可新增自定义字段。';


