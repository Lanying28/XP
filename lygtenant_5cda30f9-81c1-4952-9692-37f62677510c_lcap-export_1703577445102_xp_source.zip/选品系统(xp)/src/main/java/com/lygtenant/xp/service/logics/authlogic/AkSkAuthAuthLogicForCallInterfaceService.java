package com.lygtenant.xp.service.logics.authlogic;

import com.lygtenant.xp.config.Constants;
import com.lygtenant.xp.util.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.dto.filters.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.lang.reflect.Field;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.RoundingMode;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.http.HttpRequest;
import com.lygtenant.xp.domain.http.HttpParameter;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.functional.FunctionContainer;

/**
* auto generate AkSkAuthAuthLogicForCallInterfaceService logic
*
* @author sys
*/
@Service
public class AkSkAuthAuthLogicForCallInterfaceService {
    private static final Logger LCAP_LOGGER = LoggerFactory.getLogger(Constants.LCAP_CUSTOMIZE_LOGGER);


	public void auth(HttpRequest request) {
		String ak = "";
		String sk = "";
		String timestamp = "";
		String signature = "";
		ak="Codewave";
		CommonFunctionUtil.mapPut(request.headers,"ak",ak);
		sk="Codewave";
		timestamp=CommonFunctionUtil.toString(CommonFunctionUtil.currDateTime());
		CommonFunctionUtil.mapPut(request.headers,"timestamp",timestamp);
		signature=(ak + (sk + timestamp));
		CommonFunctionUtil.mapPut(request.headers,"signature",signature);
	}
}
