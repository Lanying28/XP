package com.lygtenant.xp.service.logics;

import com.lygtenant.xp.config.Constants;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.util.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.dto.filters.*;
import com.lygtenant.xp.service.dto.filters.atomic.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.calculate.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.compare.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.logicCalculate.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.matching.*;
import com.lygtenant.xp.service.dto.filters.logic.unary.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.exception.HttpCodeException;
import com.lygtenant.xp.service.system.configuration.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.lang.reflect.Field;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.RoundingMode;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.functional.FunctionContainer;

/**
* auto generate LCAPGetUserByUserIdCustomizeService logic
*
* @author sys
*/
@Service
public class LCAPGetUserByUserIdCustomizeService {
    private static final Logger LCAP_LOGGER = LoggerFactory.getLogger(Constants.LCAP_CUSTOMIZE_LOGGER);
	@Autowired private LCAPGetUserByUserIdCustomizeServiceMapper lCAPGetUserByUserIdCustomizeServiceMapper;

	public LCAPUser  lCAPGetUserByUserId(String userId) {
		com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_90BB04F104917B26166C550B4A1B0632 variable1 = new com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_90BB04F104917B26166C550B4A1B0632();
		LCAPUser result = new LCAPUser();
		variable1=CommonFunctionUtil.createListPage(lCAPGetUserByUserIdCustomizeServiceMapper.getAnonymousStructure_90BB04F104917B26166C550B4A1B0632(userId), lCAPGetUserByUserIdCustomizeServiceMapper.countAnonymousStructure_90BB04F104917B26166C550B4A1B0632(userId).intValue(), com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_90BB04F104917B26166C550B4A1B0632.class);
		for(Long index = 0L; index < CommonFunctionUtil.length(variable1.list); index++ ) {
			com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_47C167E7217746A55100F50A57F637C0  item = variable1.list.get(index.intValue());
			result=item.lCAPUser;
		}
		return result;
	}


}
