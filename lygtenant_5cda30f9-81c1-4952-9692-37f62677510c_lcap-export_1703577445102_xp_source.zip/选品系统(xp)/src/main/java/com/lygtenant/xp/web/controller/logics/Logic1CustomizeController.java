package com.lygtenant.xp.web.controller.logics;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.web.validation.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate Logic1CustomizeController logic
*
* @author sys
*/
@RestController
public class Logic1CustomizeController {

@Autowired private Logic1CustomizeService logic1CustomizeService;

@Validation(value = {
    @ValidationRuleGroup(
            value = "f48080b6e10f44bcbab2e21dbe0f2498",
            rules = {
            }
    ),
})
@PostMapping("/api/lcplogics/logic1")
public ApiReturn<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_48CA0B526B95BCC3B5DF53BD62B8EC14> logic1() throws Exception {
 return ApiReturn.of(logic1CustomizeService.logic1());
}
}
