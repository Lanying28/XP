package com.lygtenant.xp.web.controller.logics;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.web.validation.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate LCAPGetAllUsersCustomizeController logic
*
* @author sys
*/
@RestController
public class LCAPGetAllUsersCustomizeController {

@Autowired private LCAPGetAllUsersCustomizeService lCAPGetAllUsersCustomizeService;

@Validation(value = {
    @ValidationRuleGroup(
            value = "4cf74e40cae3410db8d2bcc2b95d19f1",
            rules = {
            }
    ),
    @ValidationRuleGroup(
            value = "36ea8f560eb24517a50069e0c21ffe17",
            rules = {
            }
    ),
})
@PostMapping("/api/lcplogics/LCAPGetAllUsers")
public ApiReturn<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_90BB04F104917B26166C550B4A1B0632> lCAPGetAllUsers() throws Exception {
 return ApiReturn.of(lCAPGetAllUsersCustomizeService.lCAPGetAllUsers());
}
}
