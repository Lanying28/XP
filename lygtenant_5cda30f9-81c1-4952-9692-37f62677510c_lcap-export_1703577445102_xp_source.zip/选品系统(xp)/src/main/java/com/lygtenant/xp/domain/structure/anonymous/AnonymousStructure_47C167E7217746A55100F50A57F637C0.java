package com.lygtenant.xp.domain.structure.anonymous;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lygtenant.xp.annotation.Label;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.structure.anonymous.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate AnonymousStructure_47C167E7217746A55100F50A57F637C0 structure
*
* @author sys
*/
@JsonAutoDetect(fieldVisibility=JsonAutoDetect.Visibility.ANY, getterVisibility=JsonAutoDetect.Visibility.NONE)
public class AnonymousStructure_47C167E7217746A55100F50A57F637C0 {
    public LCAPUser lCAPUser;

    public LCAPUser getLCAPUser() {
        return lCAPUser;
    }

    public void setLCAPUser(LCAPUser lCAPUser) {
        this.lCAPUser = lCAPUser;
    }

}
