package com.lygtenant.xp.web.controller.logics.dto;

import java.io.Serializable;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate Logic2CustomizeControllerDto
*
* @author sys
*/
public class Logic2CustomizeControllerDto {
    
    public RateFilterStructure filter;

    public RateFilterStructure getFilter() {
        return filter;
    }

    public void setFilter(RateFilterStructure filter) {
        this.filter = filter;
    }

}
