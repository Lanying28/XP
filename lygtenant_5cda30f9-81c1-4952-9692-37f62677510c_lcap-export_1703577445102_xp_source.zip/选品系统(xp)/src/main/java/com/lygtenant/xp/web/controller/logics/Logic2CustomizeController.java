package com.lygtenant.xp.web.controller.logics;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.web.validation.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.web.controller.logics.dto.*;

/**
* auto generate Logic2CustomizeController logic
*
* @author sys
*/
@RestController
public class Logic2CustomizeController {

@Autowired private Logic2CustomizeService logic2CustomizeService;

@Validation(value = {
    @ValidationRuleGroup(
            value = "cbbfc634-6027-4dc8-bdd5-7d3180abda1d",
            rules = {
            }
    ),
    @ValidationRuleGroup(
            value = "10f618b0-9b37-493e-a174-a8d4b31c9cfe",
            rules = {
            }
    ),
    @ValidationRuleGroup(
            value = "dba07245a4d84905aaed1be0c76778ab",
            rules = {
            }
    ),
    @ValidationRuleGroup(
            value = "7d729b02-7b3e-494c-b4e3-679a9737c6a8",
            rules = {
            }
    ),
    @ValidationRuleGroup(
            value = "5fc251b8-ffa1-4bcb-811d-0d1540810612",
            rules = {
            }
    ),
    @ValidationRuleGroup(
            value = "e85a73fb-e050-4bd8-b68b-61fde854c90a",
            rules = {
            }
    ),
    @ValidationRuleGroup(
            value = "6f2d5ed6-cdfe-400a-9bc7-55234551c6a5",
            rules = {
            }
    ),
})
@PostMapping("/api/lcplogics/logic2")
public ApiReturn<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_F972D0AACCDD7B64E8F5372A97DC8229> logic2(@RequestBody Logic2CustomizeControllerDto body) throws Exception {
 return ApiReturn.of(logic2CustomizeService.logic2(body.getFilter()));
}
}
