package com.lygtenant.xp.domain.ui;

public class SortEvent {
    public String field;
    public String order;
    public String compare;
}
