package com.lygtenant.xp.web.controller.logics;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.web.validation.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.web.controller.logics.dto.*;

/**
* auto generate LoadProListTableViewCustomizeController logic
*
* @author sys
*/
@RestController
public class LoadProListTableViewCustomizeController {

@Autowired private LoadProListTableViewCustomizeService loadProListTableViewCustomizeService;

@Validation(value = {
    @ValidationRuleGroup(
            value = "631da562a4c74905a3e0fa5b28c9284c",
            rules = {
            }
    ),
})
@PostMapping("/api/lcplogics/loadProListTableView")
public ApiReturn<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_ACD87413417B1A11921E715AD49CA519> loadProListTableView(@RequestBody LoadProListTableViewCustomizeControllerDto body) throws Exception {
 return ApiReturn.of(loadProListTableViewCustomizeService.loadProListTableView(body.getPage(),body.getSize(),body.getSort(),body.getOrder(),body.getProId()));
}
}
