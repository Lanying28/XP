package com.lygtenant.xp.domain.ui;

public class BaseEvent {
}
