package com.lygtenant.xp.service.dto;

/**
* auto generate LCAPUserDTO
* 制品应用中用户的业务对象
*
* @author sys
*/
public class LCAPUserDTO {
    private String userId;
    private String source;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
