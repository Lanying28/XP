package com.lygtenant.xp.config;

/**
* auto generate ImportModule
* @author sys
*/
public class ImportModuleConfiguration {
    public static final String AUTH_MODULE_PACKAGE = "com.netease.cloud.nuims";
}
