package com.lygtenant.xp.web.controller.logics;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.web.validation.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.web.controller.logics.dto.*;

/**
* auto generate LCAPLoadPermissionResourceListViewCustomizeController logic
*
* @author sys
*/
@RestController
public class LCAPLoadPermissionResourceListViewCustomizeController {

@Autowired private LCAPLoadPermissionResourceListViewCustomizeService lCAPLoadPermissionResourceListViewCustomizeService;

@Validation(value = {
    @ValidationRuleGroup(
            value = "5abb2be265c5485696cc32a43e9ba987",
            rules = {
            }
    ),
})
@PostMapping("/api/lcplogics/LCAPLoadPermissionResourceListView")
public ApiReturn<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_D8CB63E646D19A8E127BF2A118560F92> lCAPLoadPermissionResourceListView(@RequestBody LCAPLoadPermissionResourceListViewCustomizeControllerDto body) throws Exception {
 return ApiReturn.of(lCAPLoadPermissionResourceListViewCustomizeService.lCAPLoadPermissionResourceListView(body.getPage(),body.getSize()));
}
}
