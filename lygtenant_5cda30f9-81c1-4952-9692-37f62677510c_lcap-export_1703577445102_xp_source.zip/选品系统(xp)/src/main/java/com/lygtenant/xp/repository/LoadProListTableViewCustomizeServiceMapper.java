package com.lygtenant.xp.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.web.interceptor.annotation.*;
import com.lygtenant.xp.datasource.dynamic.DataSource;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;

import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate LoadProListTableViewCustomizeService Mapper
*
* @author sys
*/
public interface LoadProListTableViewCustomizeServiceMapper {

List<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_6DB3F852BF31DD04134E1C424F48EEE2> getAnonymousStructure_ACD87413417B1A11921E715AD49CA519(@Param("size") Long size,@Param("proId") Long proId,@Param("sort") String sort,@Param("page") Long page,@Param("order") String order);
Long countAnonymousStructure_ACD87413417B1A11921E715AD49CA519(@Param("size") Long size,@Param("proId") Long proId,@Param("sort") String sort,@Param("page") Long page,@Param("order") String order);

}
