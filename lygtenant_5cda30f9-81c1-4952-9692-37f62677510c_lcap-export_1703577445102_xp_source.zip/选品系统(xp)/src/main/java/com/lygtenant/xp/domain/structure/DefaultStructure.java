package com.lygtenant.xp.domain.structure;

/**
 * for nothing
 * @author sys
 * @date 2021-08-18 07:13
 */
public class DefaultStructure {
}
