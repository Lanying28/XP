package com.lygtenant.xp.domain.structure;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lygtenant.xp.annotation.Label;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate LCAPRoleBindUsersBodyStructure structure
*
* @author sys
*/
@JsonAutoDetect(fieldVisibility=JsonAutoDetect.Visibility.ANY, getterVisibility=JsonAutoDetect.Visibility.NONE)
public class LCAPRoleBindUsersBodyStructure {
    @javax.validation.constraints.NotNull
    public Long roleId;
    @javax.validation.constraints.NotNull
    public List<String> userIdList = new ArrayList <>();

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public List<String> getUserIdList() {
        return userIdList;
    }

    public void setUserIdList(List<String> userIdList) {
        this.userIdList = userIdList;
    }

}
