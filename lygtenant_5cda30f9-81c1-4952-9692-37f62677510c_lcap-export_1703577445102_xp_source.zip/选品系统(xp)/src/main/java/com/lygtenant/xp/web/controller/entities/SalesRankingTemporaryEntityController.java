package com.lygtenant.xp.web.controller.entities;

import java.io.Serializable;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.math.BigDecimal;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.*;

import com.lygtenant.xp.exception.HttpCodeException;
import com.lygtenant.xp.domain.entities.SalesRankingTemporaryEntity;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.entities.SalesRankingTemporaryEntityService;
import com.lygtenant.xp.web.ApiReturn;
import com.lygtenant.xp.service.dto.filters.EntityFilter;
import com.lygtenant.xp.service.dto.filters.AbstractQueryFilter;
import com.lygtenant.xp.service.dto.filters.FilterWrapper;
import com.lygtenant.xp.domain.PageOf;
import com.lygtenant.xp.util.JacksonUtils;
import com.lygtenant.xp.web.validation.*;

/**
* auto generate SalesRankingTemporaryEntity controller
*
* @author sys
*/
@RestController
public class SalesRankingTemporaryEntityController {
    @Resource
    private SalesRankingTemporaryEntityService service;









    /**
    * auto gen import method
    **/
    @PostMapping("/api/sales-ranking-temporary/import")
    public ApiReturn<String> importEntities(@RequestParam("file") MultipartFile file) {
        return ApiReturn.of(service.importFile(file));
    }



    /**
    * auto gen deleteBy method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "376f457bc2f94cab90d543f6476f8f32",
                rules = {
                }
        ),
    })
    @DeleteMapping("/api/sales-ranking-temporary/by")
    public ApiReturn<Long> deleteBy(@RequestBody FilterWrapper wrapper) {
        if (wrapper == null) {
            throw new HttpCodeException(400, ErrorCodeEnum.PARAM_REQUIRED.code, SalesRankingTemporaryEntity.class);
        }
        return ApiReturn.of(service.deleteBy(wrapper.getReturnExpression()));
    }
}