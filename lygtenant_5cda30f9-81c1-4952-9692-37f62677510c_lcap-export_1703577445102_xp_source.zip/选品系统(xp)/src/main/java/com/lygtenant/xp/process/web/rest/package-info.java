/**
 * Service layer beans.
 */
package com.lygtenant.xp.process.web.rest;
