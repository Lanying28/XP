/**
 * Service layer beans.
 */
package com.lygtenant.xp.service;
