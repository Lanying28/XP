package com.lygtenant.xp.web.controller.logics.dto;

import java.io.Serializable;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate Logic4CustomizeControllerDto
*
* @author sys
*/
public class Logic4CustomizeControllerDto {
    
    public String proCode;

    public String getProCode() {
        return proCode;
    }

    public void setProCode(String proCode) {
        this.proCode = proCode;
    }

}
