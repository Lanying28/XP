package com.lygtenant.xp.web.controller.logics.dto;

import java.io.Serializable;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate LCAPGetUserTableViewCustomizeControllerDto
*
* @author sys
*/
public class LCAPGetUserTableViewCustomizeControllerDto {
    
    public LCAPUser filter;
    
    public Long size;
    
    public String sort;
    
    public Long page;
    
    public String order;

    public LCAPUser getFilter() {
        return filter;
    }

    public void setFilter(LCAPUser filter) {
        this.filter = filter;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public Long getPage() {
        return page;
    }

    public void setPage(Long page) {
        this.page = page;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

}
