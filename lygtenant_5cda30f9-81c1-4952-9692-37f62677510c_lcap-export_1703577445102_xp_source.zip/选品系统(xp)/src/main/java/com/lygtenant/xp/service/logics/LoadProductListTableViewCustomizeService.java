package com.lygtenant.xp.service.logics;

import com.lygtenant.xp.config.Constants;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.util.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.dto.filters.*;
import com.lygtenant.xp.service.dto.filters.atomic.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.calculate.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.compare.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.logicCalculate.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.matching.*;
import com.lygtenant.xp.service.dto.filters.logic.unary.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.exception.HttpCodeException;
import com.lygtenant.xp.service.system.configuration.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.lang.reflect.Field;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.RoundingMode;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.functional.FunctionContainer;

/**
* auto generate LoadProductListTableViewCustomizeService logic
*
* @author sys
*/
@Service
public class LoadProductListTableViewCustomizeService {
    private static final Logger LCAP_LOGGER = LoggerFactory.getLogger(Constants.LCAP_CUSTOMIZE_LOGGER);
	@Autowired private LoadProductListTableViewCustomizeServiceMapper loadProductListTableViewCustomizeServiceMapper;

	public com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_D973E5D521E557621AB6C7C329CD488F  loadProductListTableView(Long page,Long size,String sort,String order,ProductEntity filter) {
		com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_D973E5D521E557621AB6C7C329CD488F result = new com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_D973E5D521E557621AB6C7C329CD488F();
		result=CommonFunctionUtil.createListPage(loadProductListTableViewCustomizeServiceMapper.getAnonymousStructure_D973E5D521E557621AB6C7C329CD488F(filter,size,getTableField("AnonymousStructure_9ECE35F6B2A89475F87BB2D49DE0DDB8",sort),page,order), loadProductListTableViewCustomizeServiceMapper.countAnonymousStructure_D973E5D521E557621AB6C7C329CD488F(filter,size,getTableField("AnonymousStructure_9ECE35F6B2A89475F87BB2D49DE0DDB8",sort),page,order).intValue(), com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_D973E5D521E557621AB6C7C329CD488F.class);
		return result;
	}

    private static Map<String, Map<String, String>> structureTableColumnMap = new HashMap<>();
    private static Map<String, Map<String, List<String>>> structurePropFieldMap = new HashMap<>();
    static {
        Map<String, List<String>> propColumnMap = null;
        Map<String,String> tableColumnMap = null;
        if (structureTableColumnMap.get("AnonymousStructure_9ECE35F6B2A89475F87BB2D49DE0DDB8") == null) {
        structureTableColumnMap.put("AnonymousStructure_9ECE35F6B2A89475F87BB2D49DE0DDB8",new HashMap<String, String>());
        }
        tableColumnMap = structureTableColumnMap.get("AnonymousStructure_9ECE35F6B2A89475F87BB2D49DE0DDB8");
            tableColumnMap.put("product.sex","`Product`.`sex`");
            tableColumnMap.put("product.season","`Product`.`season`");
            tableColumnMap.put("product.id","`Product`.`id`");
            tableColumnMap.put("product.proName","`Product`.`proName`");
            tableColumnMap.put("product.brand","`Product`.`brand`");
            tableColumnMap.put("product.type2","`Product`.`type2`");
            tableColumnMap.put("product.type3","`Product`.`type3`");
            tableColumnMap.put("product.updatedTime","`Product`.`updatedTime`");
            tableColumnMap.put("product.createdTime","`Product`.`createdTime`");
            tableColumnMap.put("product.updatedBy","`Product`.`updatedBy`");
            tableColumnMap.put("product.quantity","`Product`.`quantity`");
            tableColumnMap.put("product.productCode","`Product`.`productCode`");
            tableColumnMap.put("product.rate","`Product`.`rate`");
            tableColumnMap.put("product.sellingPrice","`Product`.`sellingPrice`");
            tableColumnMap.put("product.discount","`Product`.`discount`");
            tableColumnMap.put("product.salesRanking","`Product`.`salesRanking`");
            tableColumnMap.put("product.createdBy","`Product`.`createdBy`");
            tableColumnMap.put("product.type","`Product`.`type`");
        if (structurePropFieldMap.get("AnonymousStructure_9ECE35F6B2A89475F87BB2D49DE0DDB8") == null) {
            structurePropFieldMap.put("AnonymousStructure_9ECE35F6B2A89475F87BB2D49DE0DDB8",new HashMap<String, List<String>>());
        }
         propColumnMap = structurePropFieldMap.get("AnonymousStructure_9ECE35F6B2A89475F87BB2D49DE0DDB8");
        if (propColumnMap.get("updatedTime") == null){
            propColumnMap.put("updatedTime", new ArrayList<>());
            }
            propColumnMap.get("updatedTime").add("product.updatedTime");
        if (propColumnMap.get("type3") == null){
            propColumnMap.put("type3", new ArrayList<>());
            }
            propColumnMap.get("type3").add("product.type3");
        if (propColumnMap.get("type2") == null){
            propColumnMap.put("type2", new ArrayList<>());
            }
            propColumnMap.get("type2").add("product.type2");
        if (propColumnMap.get("quantity") == null){
            propColumnMap.put("quantity", new ArrayList<>());
            }
            propColumnMap.get("quantity").add("product.quantity");
        if (propColumnMap.get("updatedBy") == null){
            propColumnMap.put("updatedBy", new ArrayList<>());
            }
            propColumnMap.get("updatedBy").add("product.updatedBy");
        if (propColumnMap.get("sex") == null){
            propColumnMap.put("sex", new ArrayList<>());
            }
            propColumnMap.get("sex").add("product.sex");
        if (propColumnMap.get("discount") == null){
            propColumnMap.put("discount", new ArrayList<>());
            }
            propColumnMap.get("discount").add("product.discount");
        if (propColumnMap.get("type") == null){
            propColumnMap.put("type", new ArrayList<>());
            }
            propColumnMap.get("type").add("product.type");
        if (propColumnMap.get("sellingPrice") == null){
            propColumnMap.put("sellingPrice", new ArrayList<>());
            }
            propColumnMap.get("sellingPrice").add("product.sellingPrice");
        if (propColumnMap.get("productCode") == null){
            propColumnMap.put("productCode", new ArrayList<>());
            }
            propColumnMap.get("productCode").add("product.productCode");
        if (propColumnMap.get("rate") == null){
            propColumnMap.put("rate", new ArrayList<>());
            }
            propColumnMap.get("rate").add("product.rate");
        if (propColumnMap.get("createdBy") == null){
            propColumnMap.put("createdBy", new ArrayList<>());
            }
            propColumnMap.get("createdBy").add("product.createdBy");
        if (propColumnMap.get("salesRanking") == null){
            propColumnMap.put("salesRanking", new ArrayList<>());
            }
            propColumnMap.get("salesRanking").add("product.salesRanking");
        if (propColumnMap.get("season") == null){
            propColumnMap.put("season", new ArrayList<>());
            }
            propColumnMap.get("season").add("product.season");
        if (propColumnMap.get("createdTime") == null){
            propColumnMap.put("createdTime", new ArrayList<>());
            }
            propColumnMap.get("createdTime").add("product.createdTime");
        if (propColumnMap.get("proName") == null){
            propColumnMap.put("proName", new ArrayList<>());
            }
            propColumnMap.get("proName").add("product.proName");
        if (propColumnMap.get("id") == null){
            propColumnMap.put("id", new ArrayList<>());
            }
            propColumnMap.get("id").add("product.id");
        if (propColumnMap.get("brand") == null){
            propColumnMap.put("brand", new ArrayList<>());
            }
            propColumnMap.get("brand").add("product.brand");
    }
    private String getTableField(String structureName, String param) {
        if (structurePropFieldMap.get(structureName) == null) {
            return param;
        }
        if (param == null || "".equals(param)) {
            return null;
        }
        Map<String, String> tableColumnMap = structureTableColumnMap.get(structureName);
        Map<String, List<String>> propColumnMap = structurePropFieldMap.get(structureName);
        String[] paramSplit = param.split("\\.");
        if (paramSplit.length == 1) {
            List<String> propList = propColumnMap.get(paramSplit[0]);
            String tableColumn = getTableColumn(propList, tableColumnMap);
            if (tableColumn != null) {
                return tableColumn;
            }
        } else if (tableColumnMap.get(param) != null) {
            return tableColumnMap.get(param);
        }
        throw new HttpCodeException(404, "排序参数{" + param + "}不存在");
    }

    // for sonar check Cognitive Complexity
    private String getTableColumn(List<String> propList, Map<String, String> tableColumnMap) {
        String tableColumn = null;
        if (propList != null) {
            for (String prop : propList) {
                String str = tableColumnMap.get(prop);
                if (str == null || "".equals(str)) {
                    continue;
                }
                if (tableColumn == null) {
                    tableColumn = str;
                } else {
                    tableColumn = str.length() >= tableColumn.length() ? tableColumn : str;
                }
            }
        }

        return tableColumn;
    }

    public  <T> T getObjectTableField(String structureName,T obj,List<String> fieldNames) {
        try {
            T cloneObj = CommonFunctionUtil.clone(obj);
            for (String fieldRef : fieldNames) {
                String[] fieldNameSplit = fieldRef.split("\\.");
                Field field = obj.getClass().getDeclaredField(fieldNameSplit[0]);
                Object fieldObject = cloneObj;
                for (int fieldIndex = 1; fieldIndex < fieldNameSplit.length; fieldIndex++) {
                    fieldObject = field.get(fieldObject);
                    field = field.getType().getDeclaredField(fieldNameSplit[fieldIndex]);
                }
                    field.set(fieldObject, getTableField(structureName, (String) field.get(fieldObject)));
                }
                return cloneObj;
            } catch (Exception e) {
                throw new HttpCodeException("500", e);
            }
    }

}
