/**
 * enumeration objects.
 */
package com.lygtenant.xp.domain.enumeration;
