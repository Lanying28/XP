package com.lygtenant.xp.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lygtenant.xp.exception.HttpCodeException;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author sys
 * @date 2021-06-17
 * @since
 */
public class JacksonUtils {
    private JacksonUtils() {}
    private static ObjectMapper objectMapper = new ObjectMapper();
    static {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .registerModule(new JavaTimeModule())
                .disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
    }

    public static void setMapper(ObjectMapper mapper) {
        objectMapper = mapper;
    }

    public static String toJson(Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new HttpCodeException(HttpStatus.INTERNAL_SERVER_ERROR.value(), e);
        }
    }

    public static JsonNode toJsonNode(Object object) {
        return objectMapper.convertValue(object, JsonNode.class);
    }

    public static <T> T fromJson(String json, Class<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (IOException e) {
            throw new HttpCodeException(HttpStatus.INTERNAL_SERVER_ERROR.value(), e);
        }
    }

    public static <T> T fromJson(String json, TypeReference<?> typeRef) {
        try {
            ObjectReader reader = objectMapper.readerFor(typeRef);
            return reader.readValue(json);
        } catch (IOException e) {
            throw new HttpCodeException(HttpStatus.INTERNAL_SERVER_ERROR.value(), e);
        }
    }

    public static <T> T fromJson(Object o, Class<T> clazz) {
        try {
            return objectMapper.convertValue(o, clazz);
        } catch (IllegalArgumentException e) {
            throw new HttpCodeException(HttpStatus.INTERNAL_SERVER_ERROR.value(), e);
        }
    }

    public static <T> T fromJson(Map json, Class<T> clazz) {
        return objectMapper.convertValue(json, clazz);
    }

    public static <T> T fromJson(Map json, TypeReference<T> typeRef) {
        return objectMapper.convertValue(json, typeRef);
    }

    public static <T> List<T> fromJsonArray(String json, Class<T> clazz) {
        try {
            JavaType javaType = objectMapper.getTypeFactory().constructCollectionType(List.class, clazz);
            return objectMapper.readValue(json, javaType);
        } catch (IOException e) {
            throw new HttpCodeException(HttpStatus.INTERNAL_SERVER_ERROR.value(), e);
        }
    }

    public static <T> List<T> fromJsonArray(List<Map> jsonArray, Class<T> clazz) {
        JavaType javaType = objectMapper.getTypeFactory().constructCollectionType(List.class, clazz);
        return objectMapper.convertValue(jsonArray, javaType);
    }
}
