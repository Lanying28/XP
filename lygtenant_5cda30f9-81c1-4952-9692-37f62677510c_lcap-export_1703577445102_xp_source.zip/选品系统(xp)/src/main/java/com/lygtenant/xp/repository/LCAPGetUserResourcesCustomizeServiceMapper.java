package com.lygtenant.xp.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.web.interceptor.annotation.*;
import com.lygtenant.xp.datasource.dynamic.DataSource;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;

import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate LCAPGetUserResourcesCustomizeService Mapper
*
* @author sys
*/
public interface LCAPGetUserResourcesCustomizeServiceMapper {

List<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_B202841ADEE061731D68863F55003B0E> getAnonymousStructure_FA75F69B8BA9C34178F71FC536D2D824(@Param("userId") String userId);
Long countAnonymousStructure_FA75F69B8BA9C34178F71FC536D2D824(@Param("userId") String userId);

}
