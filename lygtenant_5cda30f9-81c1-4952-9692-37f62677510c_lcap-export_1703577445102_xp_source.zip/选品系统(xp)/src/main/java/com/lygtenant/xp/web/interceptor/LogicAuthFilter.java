package com.lygtenant.xp.web.interceptor;

import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.service.entities.LCAPLogicViewMappingService;
import com.lygtenant.xp.service.entities.LCAPPerResMappingService;
import com.lygtenant.xp.service.entities.LCAPResourceService;
import com.lygtenant.xp.service.entities.LCAPRolePerMappingService;
import com.lygtenant.xp.service.entities.LCAPUserRoleMappingService;
import com.lygtenant.xp.web.ApiReturn;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.service.dto.filters.AbstractQueryFilter;
import com.lygtenant.xp.service.dto.filters.atomic.ColumnQueryFilter;
import com.lygtenant.xp.service.dto.filters.atomic.ListLiteralQueryFilter;
import com.lygtenant.xp.service.dto.filters.atomic.StringLiteralQueryFilter;
import com.lygtenant.xp.service.dto.filters.logic.binary.compare.EqualQueryFilter;
import com.lygtenant.xp.service.dto.filters.logic.binary.matching.InQueryFilter;
import com.lygtenant.xp.task.permission.model.DeployLogicAuthMetaData;
import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.core.annotation.Order;
import org.springframework.beans.factory.annotation.Value;
import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.commons.collections4.MapUtils;
import org.springframework.core.io.ClassPathResource;

import javax.annotation.Resource;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 逻辑鉴权过滤器
 *
 * @author sys
 * @since 2.19
 */
@Order(5)
@WebFilter(filterName = "logicAuthFilter", urlPatterns = {"/api/*","/upload/*"})
public class LogicAuthFilter implements Filter {
    private final Logger log = LoggerFactory.getLogger(LogicAuthFilter.class);

    @Value("${logicAuthFlag:true}")
    private Boolean logicAuthFlag;

    public static final String LOGIC_IDENTIFIER_SEPARATOR = ":";

    @Resource
    private LCAPLogicViewMappingService logicViewMappingService;

    @Resource
    private LCAPUserRoleMappingService userRoleMappingService;

    @Resource
    private LCAPRolePerMappingService rolePerMappingService;

    @Resource
    private LCAPPerResMappingService perResMappingService;

    @Resource
    private LCAPResourceService resourceService;

    private Map<String, List<List<DeployLogicAuthMetaData>>> logicAuthMetaDataMap;




    private ObjectMapper objectMapper = new ObjectMapper();

    public static final String VIEW_COMPONENT = "component";
    public static final String VIEW_PAGE = "page";
    public static final String ALL_AUTH_VIEW_FLAG = "/";

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        loadViewLogicData();
    }

    private void loadViewLogicData(){
        logicAuthMetaDataMap = readFileToCollect("permission/logicAuthMetaData.json", new TypeReference<Map<String, List<List<DeployLogicAuthMetaData>>>>() {});
        if(Objects.isNull(logicAuthMetaDataMap)){
            log.info("LogicAuthFilter init viewLogicData from db LCAPLogicViewMapping");
            logicAuthMetaDataMap = new HashMap<>();
            List<LCAPLogicViewMapping> dbList = logicViewMappingService.list(null);
            if(!CollectionUtils.isEmpty(dbList)){
                Map<String, List<LCAPLogicViewMapping>> tempMap = dbList.stream().collect(Collectors.groupingBy(viewMapping -> viewMapping.getLogicIdentifier(), Collectors.toList()));
                tempMap.forEach((k,v) -> {
                List<List<DeployLogicAuthMetaData>> list = new ArrayList<>();
                    Map<String, List<LCAPLogicViewMapping>> groupList = v.stream().collect(Collectors.groupingBy(viewMapping -> viewMapping.getGroup() + "", Collectors.toList()));
                    groupList.forEach((k1,v1) -> {
                        List logicIdentifierList = v1.stream().filter(logicViewMapping -> !ALL_AUTH_VIEW_FLAG.equals(logicViewMapping.getResourceName())).map(item -> {
                            DeployLogicAuthMetaData deployLogicAuthMetaData = new DeployLogicAuthMetaData();
                            deployLogicAuthMetaData.setType(item.getResourceType());
                            deployLogicAuthMetaData.setUiPath(item.getResourceName());
                            return deployLogicAuthMetaData;
                        }).collect(Collectors.toList());
                        list.add(logicIdentifierList);
                    });
                    logicAuthMetaDataMap.put(k, list);
                });
            }
        }else {
             log.info("LogicAuthFilter init viewLogicData from permission/logicAuthMetaData.json");
        }
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        if(!logicAuthFlag) {
            log.debug("逻辑鉴权开关关闭");
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        // 1. 识别到当前的请求路径
        HttpServletRequest httpRequest = (HttpServletRequest) servletRequest;
        String requestURI = httpRequest.getRequestURI();
        String method = httpRequest.getMethod();
        String logicIdentifier = requestURI + LOGIC_IDENTIFIER_SEPARATOR + method;
        log.info("当前请求的逻辑标识: {}", logicIdentifier);

        if(isUploadRequest(requestURI, method)) {
            log.info("upload 非POST逻辑{} 无需鉴权", logicIdentifier);
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        // 2. 判断是否为白名单接口（认证、登录、流程相关系统逻辑接口）
        for (String allAuthApi : apiWhiteList()) {
            if (logicIdentifier.startsWith(allAuthApi)) {
                log.warn("白名单逻辑{} 无需鉴权", logicIdentifier);
                filterChain.doFilter(servletRequest, servletResponse);
                return;
            }
        }

        HttpServletResponse httpResponse = (HttpServletResponse) servletResponse;

        //如果initConfig阶段失败，就重新加载一次
        if(Objects.isNull(logicAuthMetaDataMap)){
            loadViewLogicData();
        }

        // 3. 查询应用的逻辑和资源绑定关系（优化可放入缓存）
        if (isContainsLogicIdentifier(logicIdentifier)) {
            // 表示这个逻辑创建出来 未与页面资源进行关联
            log.warn("未查询到逻辑页面资源关联关系 逻辑{}鉴权不通过", logicIdentifier);
            handleReturn(httpResponse, "逻辑鉴权不通过");
            return;
        }
        // 3.1 如果当前逻辑关联的页面资源是 空数组则表示该逻辑关联了无需登录即可访问的页面，所以直接放行
        if(isShouldNotAuth(logicIdentifier)){
            log.debug("逻辑{} 无需鉴权", logicIdentifier);
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        // 4. 判断当前用户是否登录，如果3.1没有放行 则说明逻辑没有关联无需鉴权的页面，所以用户需要登录才能访问这个逻辑
        UserContext.UserInfo currentUser = UserContext.getCurrentUser();
        if (Objects.isNull(currentUser)) {
            log.warn("当前用户未登录 逻辑{} 鉴权不通过", logicIdentifier);
            handleReturn(httpResponse, "逻辑鉴权不通过");
            return;
        }

        // 5. 调用系统默认逻辑鉴权策略检查是否有权限访问
        List<String> currentUserResNames = defaultPermissionCheck(logicIdentifier, httpResponse, currentUser);
        if (CollectionUtils.isEmpty(currentUserResNames)) {
            log.warn("当前用户关联资源为空 逻辑{} 鉴权不通过", logicIdentifier);
            handleReturn(httpResponse, "用户关联资源为空，逻辑鉴权不通过");
            return;
        }
        List<List<DeployLogicAuthMetaData>> viewMappingsInGroupMap =  logicAuthMetaDataMap.get(logicIdentifier);
        for (int i = 0; i < viewMappingsInGroupMap.size(); i++) {
            // 一个组里的要全部满足才算通过，一个entry.getValue()表示一个组里的内容
            // 不同组之间的有一个组满足就可以通过
            // 父子页面会同步绑定角色，子页面有的角色 父页面一定有，父页面有的子页面不一定有
            List<DeployLogicAuthMetaData> viewMappingsInGroup = viewMappingsInGroupMap.get(i);
            // 组内的每一个元素，如果类型是page，用户关联的资源以此值开头就可以访问
            // 如果类型是component，用户关联的资源要完全相等于此值才可以访问
            boolean allMatch = viewMappingsInGroup.stream().allMatch(viewMapping -> isViewMappingMatch(currentUserResNames, viewMapping));
            if (allMatch) {
                filterChain.doFilter(servletRequest, servletResponse);
                return;
            }
        }

        handleReturn(httpResponse, "逻辑鉴权不通过");
    }

    private boolean isUploadRequest(String requestURI, String method) {
        return StringUtils.isNotBlank(requestURI) && requestURI.startsWith("/upload") &&!"POST".equals(method);
    }

    private boolean isContainsLogicIdentifier(String logicIdentifier) {
        return MapUtils.isEmpty(logicAuthMetaDataMap) || !logicAuthMetaDataMap.containsKey(logicIdentifier);
    }

    private boolean isShouldNotAuth(String logicIdentifier) {
        return logicAuthMetaDataMap.containsKey(logicIdentifier) &&
                !CollectionUtils.isEmpty(logicAuthMetaDataMap.get(logicIdentifier)) &&
                CollectionUtils.isEmpty(logicAuthMetaDataMap.get(logicIdentifier).get(0));
    }

    private boolean isViewMappingMatch(List<String> currentUserResNames, DeployLogicAuthMetaData viewMapping) {
        if (VIEW_COMPONENT.equals(viewMapping.getType())) {
            return currentUserResNames.stream().anyMatch(currentUserRes -> StringUtils.equals(currentUserRes, viewMapping.getUiPath()));
        } else {
            return currentUserResNames.stream().anyMatch(currentUserRes -> StringUtils.startsWith(viewMapping.getUiPath(), currentUserRes));
        }
    }

    private List<String> defaultPermissionCheck(String logicIdentifier, HttpServletResponse httpResponse, UserContext.UserInfo currentUser) throws IOException {
         // 6. 查询当前用户关联的资源
        // 6.1 查询用户关联角色
        AbstractQueryFilter queryFilter = new EqualQueryFilter()
            .left(new ColumnQueryFilter(null, null, "userId", "userId"))
            .right(new StringLiteralQueryFilter(currentUser.getUserId()));
        List<LCAPUserRoleMapping> allUserRoleMapping = userRoleMappingService.list(queryFilter);
        if (CollectionUtils.isEmpty(allUserRoleMapping)) {
            log.warn("当前用户{} 未关联任何角色, 逻辑{} 调用失败", currentUser.getUserId(), logicIdentifier);
            handleReturn(httpResponse, "当前用户未查询到关联角色信息 逻辑调用失败");
            return Collections.emptyList();
        }
        List<Long> roleIds = allUserRoleMapping.stream().map(LCAPUserRoleMapping::getRoleId).collect(Collectors.toList());
        // 6.2 查询角色关联权限
        queryFilter = new InQueryFilter()
            .left(new ColumnQueryFilter(null, null, "roleId", "roleId")).right(new ListLiteralQueryFilter(roleIds));
        List<LCAPRolePerMapping> allRolePerMapping = rolePerMappingService.list(queryFilter);
            if (CollectionUtils.isEmpty(allRolePerMapping)) {
            log.warn("当前用户{} 未查询到关联权限数据, 逻辑{} 调用失败", currentUser.getUserId(), logicIdentifier);
            handleReturn(httpResponse, "当前用户未查询到角色关联权限信息 逻辑调用失败");
            return Collections.emptyList();
        }
        List<Long> permissionIds = allRolePerMapping.stream().map(LCAPRolePerMapping::getPermissionId).collect(Collectors.toList());
        // 6.3 查询权限关联的资源
        queryFilter = new InQueryFilter()
        .left(new ColumnQueryFilter(null, null, "permissionId", "permissionId")).right(new ListLiteralQueryFilter(permissionIds));
        List<LCAPPerResMapping> allPerResMapping = perResMappingService.list(queryFilter);
            if (CollectionUtils.isEmpty(allPerResMapping)) {
            log.warn("当前用户{} 未查询到关联的资源信息，逻辑{} 调用失败", currentUser.getUserId(), logicIdentifier);
            handleReturn(httpResponse, "当前用户未查询到权限关联资源信息 逻辑调用失败");
            return Collections.emptyList();
        }
        List<Long> resourceIds = allPerResMapping.stream().map(LCAPPerResMapping::getResourceId).collect(Collectors.toList());
        // 6.4 查询资源信息
        queryFilter = new InQueryFilter()
        .left(new ColumnQueryFilter(null, null, "id", "id")).right(new ListLiteralQueryFilter(resourceIds));
        List<LCAPResource> allResources = resourceService.list(queryFilter);
        if (CollectionUtils.isEmpty(allResources)) {
            log.warn("当前用户{} 未查询到资源信息，逻辑{} 调用失败", currentUser.getUserId(), logicIdentifier);
            handleReturn(httpResponse, "当前用户未查询到资源信息 逻辑调用失败");
            return Collections.emptyList();
        }
       return allResources.stream().map(LCAPResource::getName).collect(Collectors.toList());
    }


    private static List<String> apiWhiteList() {
        List<String> verifyApis = Arrays.asList("/api/user");
        List<String> systemApis = Arrays.asList("/api/system");
        return Stream.concat(verifyApis.stream(), systemApis.stream()).collect(Collectors.toList());
    }

    private <T> T readFileToCollect(String filePath, TypeReference<T> typeReference) {
        ClassPathResource classPathResource = new ClassPathResource(filePath);
        InputStream inputStream = null;
        try {
            inputStream = classPathResource.getInputStream();
        } catch (IOException e) {
            log.error("应用启动时权限数据 {} 读取失败 {}", filePath, e);
            return null;
        }
        T readValue = null;
        try {
            readValue = objectMapper.readValue(inputStream, typeReference);
        } catch (IOException e) {
            log.error("应用启动时权限数据 {} 转换失败 {}", filePath, e);
            return null;
        }
        return readValue;
    }

    private void handleReturn(HttpServletResponse response, String returnMessage) throws IOException {
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType("application/json");
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        ApiReturn<String> unAuthReturn = ApiReturn.of("", HttpStatus.UNAUTHORIZED.value(), returnMessage);
        response.getWriter().write(objectMapper.writeValueAsString(unAuthReturn));
    }
}
