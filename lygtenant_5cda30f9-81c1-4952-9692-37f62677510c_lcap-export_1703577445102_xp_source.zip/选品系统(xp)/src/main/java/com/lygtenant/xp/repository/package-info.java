/**
 * Spring Data JPA repositories.
 */
package com.lygtenant.xp.repository;
