package com.lygtenant.xp.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.web.interceptor.annotation.*;
import com.lygtenant.xp.datasource.dynamic.DataSource;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;

import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate LCAPIsRoleNameRepeatedCustomizeService Mapper
*
* @author sys
*/
public interface LCAPIsRoleNameRepeatedCustomizeServiceMapper {

List<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_70791B893F53C2EFB9E501591763B020> getAnonymousStructure_CAC5152BAE2C91DD609E3DFEE343ACC6(@Param("roleName") String roleName);
Long countAnonymousStructure_CAC5152BAE2C91DD609E3DFEE343ACC6(@Param("roleName") String roleName);

}
