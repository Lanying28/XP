package com.lygtenant.xp.domain.structure.anonymous;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lygtenant.xp.annotation.Label;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.structure.anonymous.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate AnonymousStructure_ACD87413417B1A11921E715AD49CA519 structure
*
* @author sys
*/
@JsonAutoDetect(fieldVisibility=JsonAutoDetect.Visibility.ANY, getterVisibility=JsonAutoDetect.Visibility.NONE)
public class AnonymousStructure_ACD87413417B1A11921E715AD49CA519 {
    public List<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_6DB3F852BF31DD04134E1C424F48EEE2> list = new ArrayList <>();
    public Long total;

    public List<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_6DB3F852BF31DD04134E1C424F48EEE2> getList() {
        return list;
    }

    public void setList(List<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_6DB3F852BF31DD04134E1C424F48EEE2> list) {
        this.list = list;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

}
