package com.lygtenant.xp.web.controller.entities;

import java.io.Serializable;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.math.BigDecimal;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.*;

import com.lygtenant.xp.exception.HttpCodeException;
import com.lygtenant.xp.domain.entities.ProductEntity;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.entities.ProductEntityService;
import com.lygtenant.xp.web.ApiReturn;
import com.lygtenant.xp.service.dto.filters.EntityFilter;
import com.lygtenant.xp.service.dto.filters.AbstractQueryFilter;
import com.lygtenant.xp.service.dto.filters.FilterWrapper;
import com.lygtenant.xp.domain.PageOf;
import com.lygtenant.xp.util.JacksonUtils;
import com.lygtenant.xp.web.validation.*;

/**
* auto generate ProductEntity controller
*
* @author sys
*/
@RestController
public class ProductEntityController {
    @Resource
    private ProductEntityService service;

    /**
    * auto gen create method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "285ce16be38043208733027f0b991859",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "9f6de5f27ad7487e9b26ef30d14d1a34",
                rules = {
                }
        ),
    })
    @PostMapping("/api/product")
    public ApiReturn<ProductEntity> create(@RequestBody ProductEntity body) {
        return ApiReturn.of(service.create(body));
    }


    /**
    * auto gen update method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "a0c63e01d906460581f4395a8f24eabb",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "80f6f47e43c547718b66dca3fac1efd3",
                rules = {
                }
        ),
    })
    @PutMapping("/api/product")
    public ApiReturn<ProductEntity> update(@RequestBody EntityFilter filter) {
        if (filter == null || filter.getEntity() == null) {
            throw new HttpCodeException(400, ErrorCodeEnum.PARAM_REQUIRED.code, "");
        }
        Map map = filter.getEntity();
        ProductEntity entity = JacksonUtils.fromJson(map, ProductEntity.class);
        List<String> updateFields = filter.getProperties();
        return ApiReturn.of(service.update(entity, updateFields));
    }



    /**
    * auto gen delete method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "385ae666660f42b9af4a6c35564e6b9a",
                rules = {
                }
        ),
    })
    @DeleteMapping("/api/product")
    public ApiReturn<Long> delete( @RequestParam(required = true) Long id ) { 
        return ApiReturn.of(service.delete( id )); 
    }


    /**
    * auto gen get method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "cf541d4896a943fe8936d571e59fac2c",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "03af993a21414f8f9401088dfc0328fd",
                rules = {
                }
        ),
    })
    @GetMapping("/api/product")
    public ApiReturn<ProductEntity> get( @RequestParam(required = true) Long id ) { 
        return ApiReturn.of(service.get( id )); 
    }

    /**
    * auto gen import method
    **/
    @PostMapping("/api/product/import")
    public ApiReturn<String> importEntities(@RequestParam("file") MultipartFile file) {
        return ApiReturn.of(service.importFile(file));
    }


    /**
    * auto gen updateBy method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "56fff41c-8103-42a8-82fd-8b8b9eda0168",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "0b7c5a20-eff7-4d2e-835d-17e3f73f686b",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "79e85ba3-2393-4030-83ed-970e8f736b24",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "193ce22e-7c88-42c4-9a23-af63aecd8205",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "2b0b7ca5-0f63-4dc8-8334-12e0bc4ab592",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "931c8223-9a02-41c2-a12f-7242c2c5cef8",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "e72cd79f-4665-42a8-8bdd-e7d9f59e2b78",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "2880231d-a929-404a-b324-2a640e0b918b",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "8ccb68d4-9e60-4a4e-a7fd-0e02ed27c182",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "9621bd88-e3f7-4fe9-b387-44f34e536cac",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "5c2c938f-2c07-4e74-9b8d-d62a51cf3c51",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "03555b5a-e426-4db6-a46e-52370e4cc452",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "d1fbecec-1e55-488a-a316-59eb7127fd6d",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "84cb8dbfcd444e959936c18425c98eda",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "f321ee65-a5f6-4c93-a8e1-3712dae2d800",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "9ab88605-f5cb-416c-ac4b-cecb6877b0b0",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "e9a69a20-6b02-40bc-a69e-6c46aa789577",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "8dc8c69c-49e5-4415-b9b1-938e938c715c",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "b0b96bf6-ee7c-4ed3-bda1-cf035d17d618",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "4cf2e667-0f06-4bb7-9d7d-f0ef7b8a4b2d",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "81e287d3-04e8-411e-b191-5363a7aeb6ea",
                rules = {
                }
        ),
        @ValidationRuleGroup(
                value = "da6d0988-c3b8-4cb2-a247-7b10dbbcb7d8",
                rules = {
                }
        ),
    })
    @PutMapping("/api/product/by")
    public ApiReturn<Long> updateBy(@RequestBody EntityFilter filter) {
        if (filter == null || filter.getEntity() == null) {
            throw new HttpCodeException(400, ErrorCodeEnum.PARAM_REQUIRED.code, "");
        }
        Map map = filter.getEntity();
        ProductEntity entity = JacksonUtils.fromJson(map, ProductEntity.class);
        List<String> updateFields = filter.getProperties();
        return ApiReturn.of(service.updateBy(entity, updateFields, filter.getFilter().getReturnExpression()));
    }

    /**
    * auto gen deleteBy method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "f400395e33e44dde98bed7fdd54f3582",
                rules = {
                }
        ),
    })
    @DeleteMapping("/api/product/by")
    public ApiReturn<Long> deleteBy(@RequestBody FilterWrapper wrapper) {
        if (wrapper == null) {
            throw new HttpCodeException(400, ErrorCodeEnum.PARAM_REQUIRED.code, ProductEntity.class);
        }
        return ApiReturn.of(service.deleteBy(wrapper.getReturnExpression()));
    }
}