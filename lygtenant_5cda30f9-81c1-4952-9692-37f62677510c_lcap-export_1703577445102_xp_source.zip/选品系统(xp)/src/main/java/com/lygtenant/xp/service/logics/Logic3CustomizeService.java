package com.lygtenant.xp.service.logics;

import com.lygtenant.xp.config.Constants;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.util.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.dto.filters.*;
import com.lygtenant.xp.service.dto.filters.atomic.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.calculate.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.compare.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.logicCalculate.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.matching.*;
import com.lygtenant.xp.service.dto.filters.logic.unary.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.exception.HttpCodeException;
import com.lygtenant.xp.service.system.configuration.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.lang.reflect.Field;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.RoundingMode;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.functional.FunctionContainer;

/**
* auto generate Logic3CustomizeService logic
*
* @author sys
*/
@Service
public class Logic3CustomizeService {
    private static final Logger LCAP_LOGGER = LoggerFactory.getLogger(Constants.LCAP_CUSTOMIZE_LOGGER);
	@Autowired private Logic3CustomizeServiceMapper logic3CustomizeServiceMapper;

	public com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_696132E2866BB3A7304ADB01F51B02DD  logic3() {
		com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_696132E2866BB3A7304ADB01F51B02DD result = new com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_696132E2866BB3A7304ADB01F51B02DD();
		result=CommonFunctionUtil.createListPage(logic3CustomizeServiceMapper.getAnonymousStructure_696132E2866BB3A7304ADB01F51B02DD(), logic3CustomizeServiceMapper.countAnonymousStructure_696132E2866BB3A7304ADB01F51B02DD().intValue(), com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_696132E2866BB3A7304ADB01F51B02DD.class);
		return result;
	}


}
