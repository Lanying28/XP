package com.lygtenant.xp.repository.entities;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;
import java.math.BigDecimal;
import com.lygtenant.xp.domain.entities.SalesRankingTemporaryEntity;
import com.lygtenant.xp.repository.ReferenceHandleMapper;
import com.lygtenant.xp.service.dto.filters.AbstractQueryFilter;
import org.apache.ibatis.annotations.Param;
/**
* auto generate SalesRankingTemporaryEntity Mapper
*
* @author sys
*/
public interface SalesRankingTemporaryEntityMapper extends ReferenceHandleMapper {

    int insert(SalesRankingTemporaryEntity bean);
    int batchInsert(List<SalesRankingTemporaryEntity> beans);
    List<SalesRankingTemporaryEntity> selectList(@Param("filter") AbstractQueryFilter filter);
    int count(@Param("filter") AbstractQueryFilter filter);

    int update(SalesRankingTemporaryEntity bean, List<String> updateFields);
    int batchUpdate(List<SalesRankingTemporaryEntity> beans, List<String> updateFields);
    int delete(Long id);
    int batchDelete(List<Long> ids);
    SalesRankingTemporaryEntity selectOne(Long id);

    int createOrUpdate(SalesRankingTemporaryEntity bean);
    int updateBy(SalesRankingTemporaryEntity bean, List<String> updateFields, AbstractQueryFilter filter);
    int deleteBy(@Param("filter") AbstractQueryFilter filter);

}