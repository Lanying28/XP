package com.lygtenant.xp.task.permission;

import com.lygtenant.xp.domain.entities.*;

import com.lygtenant.xp.iam.permission.AppStartPermissionDataService;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.repository.entities.LCAPLogicViewMappingMapper;
import com.lygtenant.xp.task.permission.model.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.repository.entities.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

/**
* 应用启动时权限数据上报任务类
*
* @author sys
* @since 2.22
*/
@Component
public class AppStartPermissionTask implements ApplicationRunner {

    Logger log = LoggerFactory.getLogger(AppStartPermissionTask.class);

    @Resource
    private ObjectMapper objectMapper;

    @Resource
    private LCAPLogicViewMappingService logicViewMappingService;

    @Resource
    private LCAPLogicViewMappingMapper logicViewMappingMapper;

    @Resource
    private AppStartPermissionDataService permissionDataService;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void run(ApplicationArguments args) throws Exception {
        long begin = System.currentTimeMillis();
        log.info("应用启动时处理权限数据开始----->>>");
        // 1. 构建权限数据包
        DeployPermissionPack permissionPack = null;
        try {
            permissionPack = buildPermissionPack();
        } catch (Exception e) {
            log.error("应用启动时构建权限数据包失败: {}", e);
            return;
        }

        // 1 元数据处理
        // 1.1 逻辑鉴权数据
        handleLogicAuthData(permissionPack.getLogicAuthMetaDataCollect());

        // 2. 执行默认权限数据上报逻辑
        // 如果没有扩展实现 就走默认上报权限的逻辑
        permissionDataService.permissionDataProcess(permissionPack);
        log.info("应用启动时处理权限数据结束。 耗时: {} ms", System.currentTimeMillis() - begin);
    }

    private DeployPermissionPack buildPermissionPack() {
        DeployPermissionPack packBuilder = new DeployPermissionPack();
        // 读取逻辑鉴权元数据
        Map<String, List<List<DeployLogicAuthMetaData>>> logicAuthMetaData = readFileToCollect("permission/logicAuthMetaData.json", new TypeReference<Map<String, List<List<DeployLogicAuthMetaData>>>>() {
        });
        packBuilder.setLogicAuthMetaDataCollect(logicAuthMetaData);
        // 1.2 资源数据
        List<DeployResourceMetaData> resourceMetaData = readFileToCollect("permission/resourceMetaData.json", new TypeReference<List<DeployResourceMetaData>>() {
        });
        packBuilder.setResourceMetaDataCollect(resourceMetaData);
        // 1.3 权限数据
        List<DeployPermissionMetaData> permissionMetaData = readFileToCollect("permission/permissionMetaData.json", new TypeReference<List<DeployPermissionMetaData>>() {
        });
        packBuilder.setPermissionMetaDataCollect(permissionMetaData);
        // 1.4 角色数据
        List<DeployRoleMetaData> roleMetaData = readFileToCollect("permission/roleMetaData.json", new TypeReference<List<DeployRoleMetaData>>() {
        });
        packBuilder.setRoleMetaDataCollect(roleMetaData);
        // 1.5 用户数据
        List<DeployUserMetaData> userMetaData = readFileToCollect("permission/userMetaData.json", new TypeReference<List<DeployUserMetaData>>() {
        });
        packBuilder.setUserMetaDataCollect(userMetaData);
        List<DeployRoleResourceMetaData> roleResourceMetaData = readFileToCollect("permission/roleResourceMetaData.json", new TypeReference<List<DeployRoleResourceMetaData>>() {
        });
        packBuilder.setRoleResourceMetaDataCollect(roleResourceMetaData);
        return packBuilder;
    }
    private void handleLogicAuthData(Map<String, List<List<DeployLogicAuthMetaData>>> logicAuthMetaData) {
        // 2.2 逻辑鉴权数据写入数据库
        logicAuthDataToDB(logicAuthMetaData);
    }

    private void logicAuthDataToDB(Map<String, List<List<DeployLogicAuthMetaData>>> logicAuthMetaData) {
        if (CollectionUtils.isEmpty(logicAuthMetaData)) {
            log.debug("应用启动时读取到逻辑鉴权上报列表为空");
            return;
        }
        long currentTimeMillis = System.currentTimeMillis();
        long group = 0;
        List<LCAPLogicViewMapping> logicViewMappingsToSave = new ArrayList<>();
        for (Map.Entry<String, List<List<DeployLogicAuthMetaData>>> entry : logicAuthMetaData.entrySet()) {
            String logicIdentifier = entry.getKey();
            // 逻辑关联的UI资源
            List<List<DeployLogicAuthMetaData>> logicsMappingUIs = entry.getValue();
            for (List<DeployLogicAuthMetaData> tmpList : logicsMappingUIs) {
                if (CollectionUtils.isEmpty(tmpList)) {
                    // 如果集合为空，表明此逻辑任何人可以调用，此时集合为空，上层集合只有当前集合一个元素
                    LCAPLogicViewMapping logicViewMapping = new LCAPLogicViewMapping();
                    logicViewMapping.setChangeTime(currentTimeMillis);
                    logicViewMapping.setLogicIdentifier(logicIdentifier);
                    logicViewMapping.setGroup(group);
                    logicViewMapping.setResourceName("/");
                    logicViewMapping.setResourceType("page");
                    logicViewMappingsToSave.add(logicViewMapping);
                } else {
                    for (DeployLogicAuthMetaData metaData : tmpList) {
                        LCAPLogicViewMapping logicViewMapping = new LCAPLogicViewMapping();
                        logicViewMapping.setChangeTime(currentTimeMillis);
                        logicViewMapping.setLogicIdentifier(logicIdentifier);
                        logicViewMapping.setGroup(group);
                        logicViewMapping.setResourceName(metaData.getUiPath());
                        logicViewMapping.setResourceType(metaData.getType());
                        logicViewMappingsToSave.add(logicViewMapping);
                    }
                }
                group++;
            }
        }
        List<LCAPLogicViewMapping> list = logicViewMappingService.list(null);
        if (!CollectionUtils.isEmpty(list)) {
            logicViewMappingMapper.batchDelete(list.stream().map(LCAPLogicViewMapping::getId).collect(Collectors.toList()));
        }
        logicViewMappingService.batchCreate(logicViewMappingsToSave);
    }

    private <T> T readFileToCollect(String filePath, TypeReference<T> typeReference) {
        ClassPathResource classPathResource = new ClassPathResource(filePath);
        InputStream inputStream = null;
        try {
            inputStream = classPathResource.getInputStream();
        } catch (IOException e) {
            log.error("应用启动时权限数据 {} 读取失败 {}", filePath, e);
            return null;
        }
        T readValue = null;
        try {
            readValue = objectMapper.readValue(inputStream, typeReference);
        } catch (IOException e) {
            log.error("应用启动时权限数据 {} 转换失败 {}", filePath, e);
            return null;
        }
        return readValue;
    }
}
