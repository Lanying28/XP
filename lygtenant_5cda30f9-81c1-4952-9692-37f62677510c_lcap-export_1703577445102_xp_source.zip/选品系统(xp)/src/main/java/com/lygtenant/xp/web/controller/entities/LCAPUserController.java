package com.lygtenant.xp.web.controller.entities;

import java.io.Serializable;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.math.BigDecimal;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.*;

import com.lygtenant.xp.exception.HttpCodeException;
import com.lygtenant.xp.domain.entities.LCAPUser;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.entities.LCAPUserService;
import com.lygtenant.xp.web.ApiReturn;
import com.lygtenant.xp.service.dto.filters.EntityFilter;
import com.lygtenant.xp.service.dto.filters.AbstractQueryFilter;
import com.lygtenant.xp.service.dto.filters.FilterWrapper;
import com.lygtenant.xp.domain.PageOf;
import com.lygtenant.xp.util.JacksonUtils;
import com.lygtenant.xp.web.validation.*;

/**
* auto generate LCAPUser controller
*
* @author sys
*/
@RestController
public class LCAPUserController {
    @Resource
    private LCAPUserService service;

    /**
    * auto gen create method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "775e97be796b4929aea9b35397f50854",
                rules = {
                @ValidationRule(value = "filled", targetName = "body.userName", argvs = ""),
                @ValidationRule(value = "required", targetName = "body.password", argvs = ""),
                @ValidationRule(value = "mobile", targetName = "body.phone", argvs = "{\"locale\":\"zh-CN\",\"strict\":null}"),
                @ValidationRule(value = "email", targetName = "body.email", argvs = ""),
                }
        ),
    })
    @PostMapping("/api/l-c-a-p-user")
    public ApiReturn<LCAPUser> create(@RequestBody LCAPUser body) {
        return ApiReturn.of(service.create(body));
    }


    /**
    * auto gen update method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "6fd6deca1ba74926a27e76bb2d319250",
                rules = {
                @ValidationRule(value = "filled", targetName = "filter.entity.userName", argvs = ""),
                @ValidationRule(value = "required", targetName = "filter.entity.password", argvs = ""),
                @ValidationRule(value = "mobile", targetName = "filter.entity.phone", argvs = "{\"locale\":\"zh-CN\",\"strict\":null}"),
                @ValidationRule(value = "email", targetName = "filter.entity.email", argvs = ""),
                }
        ),
    })
    @PutMapping("/api/l-c-a-p-user")
    public ApiReturn<LCAPUser> update(@RequestBody EntityFilter filter) {
        if (filter == null || filter.getEntity() == null) {
            throw new HttpCodeException(400, ErrorCodeEnum.PARAM_REQUIRED.code, "");
        }
        Map map = filter.getEntity();
        LCAPUser entity = JacksonUtils.fromJson(map, LCAPUser.class);
        List<String> updateFields = filter.getProperties();
        return ApiReturn.of(service.update(entity, updateFields));
    }



    /**
    * auto gen delete method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "6d5e5bb1b1754825ab17a119e1433fdb",
                rules = {
                }
        ),
    })
    @DeleteMapping("/api/l-c-a-p-user")
    public ApiReturn<Long> delete( @RequestParam(required = true) Long id ) { 
        return ApiReturn.of(service.delete( id )); 
    }



    /**
    * auto gen import method
    **/
    @PostMapping("/api/l-c-a-p-user/import")
    public ApiReturn<String> importEntities(@RequestParam("file") MultipartFile file) {
        return ApiReturn.of(service.importFile(file));
    }



}