package com.lygtenant.xp.service.logics;

import com.lygtenant.xp.config.Constants;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.util.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.dto.filters.*;
import com.lygtenant.xp.service.dto.filters.atomic.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.calculate.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.compare.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.logicCalculate.*;
import com.lygtenant.xp.service.dto.filters.logic.binary.matching.*;
import com.lygtenant.xp.service.dto.filters.logic.unary.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.exception.HttpCodeException;
import com.lygtenant.xp.service.system.configuration.*;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.lang.reflect.Field;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.RoundingMode;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.functional.FunctionContainer;

/**
* auto generate LoadAddRoleUserTableViewCustomizeService logic
*
* @author sys
*/
@Service
public class LoadAddRoleUserTableViewCustomizeService {
    private static final Logger LCAP_LOGGER = LoggerFactory.getLogger(Constants.LCAP_CUSTOMIZE_LOGGER);
	@Autowired private LoadAddRoleUserTableViewCustomizeServiceMapper loadAddRoleUserTableViewCustomizeServiceMapper;

	public com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_A43B95DDE943F37E89AA74CCF8732C90  loadAddRoleUserTableView(Long page,Long size,String sort,String order) {
		com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_A43B95DDE943F37E89AA74CCF8732C90 result = new com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_A43B95DDE943F37E89AA74CCF8732C90();
		result=CommonFunctionUtil.createListPage(loadAddRoleUserTableViewCustomizeServiceMapper.getAnonymousStructure_A43B95DDE943F37E89AA74CCF8732C90(size,getTableField("AnonymousStructure_99BA20F3093BB3AC3F3CA0BCA6D65EB8",sort),page,order), loadAddRoleUserTableViewCustomizeServiceMapper.countAnonymousStructure_A43B95DDE943F37E89AA74CCF8732C90(size,getTableField("AnonymousStructure_99BA20F3093BB3AC3F3CA0BCA6D65EB8",sort),page,order).intValue(), com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_A43B95DDE943F37E89AA74CCF8732C90.class);
		return result;
	}

    private static Map<String, Map<String, String>> structureTableColumnMap = new HashMap<>();
    private static Map<String, Map<String, List<String>>> structurePropFieldMap = new HashMap<>();
    static {
        Map<String, List<String>> propColumnMap = null;
        Map<String,String> tableColumnMap = null;
        if (structureTableColumnMap.get("AnonymousStructure_99BA20F3093BB3AC3F3CA0BCA6D65EB8") == null) {
        structureTableColumnMap.put("AnonymousStructure_99BA20F3093BB3AC3F3CA0BCA6D65EB8",new HashMap<String, String>());
        }
        tableColumnMap = structureTableColumnMap.get("AnonymousStructure_99BA20F3093BB3AC3F3CA0BCA6D65EB8");
            tableColumnMap.put("lCAPUserRoleMapping.createdTime","`LCAPUserRoleMapping_5cda30`.`createdTime`");
            tableColumnMap.put("lCAPRole.updatedTime","`LCAPRole_5cda30`.`updatedTime`");
            tableColumnMap.put("lCAPRole.updatedBy","`LCAPRole_5cda30`.`updatedBy`");
            tableColumnMap.put("lCAPRole.editable","`LCAPRole_5cda30`.`editable`");
            tableColumnMap.put("lCAPUserRoleMapping.createdBy","`LCAPUserRoleMapping_5cda30`.`createdBy`");
            tableColumnMap.put("lCAPUserRoleMapping.updatedTime","`LCAPUserRoleMapping_5cda30`.`updatedTime`");
            tableColumnMap.put("lCAPUserRoleMapping.userName","`LCAPUserRoleMapping_5cda30`.`userName`");
            tableColumnMap.put("lCAPRole.roleStatus","`LCAPRole_5cda30`.`roleStatus`");
            tableColumnMap.put("lCAPRole.name","`LCAPRole_5cda30`.`name`");
            tableColumnMap.put("lCAPRole.createdBy","`LCAPRole_5cda30`.`createdBy`");
            tableColumnMap.put("lCAPRole.id","`LCAPRole_5cda30`.`id`");
            tableColumnMap.put("lCAPRole.createdTime","`LCAPRole_5cda30`.`createdTime`");
            tableColumnMap.put("lCAPRole.description","`LCAPRole_5cda30`.`description`");
            tableColumnMap.put("lCAPUserRoleMapping.updatedBy","`LCAPUserRoleMapping_5cda30`.`updatedBy`");
            tableColumnMap.put("lCAPUserRoleMapping.source","`LCAPUserRoleMapping_5cda30`.`source`");
            tableColumnMap.put("lCAPUserRoleMapping.roleId","`LCAPUserRoleMapping_5cda30`.`roleId`");
            tableColumnMap.put("lCAPUserRoleMapping.userId","`LCAPUserRoleMapping_5cda30`.`userId`");
            tableColumnMap.put("lCAPRole.uuid","`LCAPRole_5cda30`.`uuid`");
            tableColumnMap.put("lCAPUserRoleMapping.id","`LCAPUserRoleMapping_5cda30`.`id`");
        if (structurePropFieldMap.get("AnonymousStructure_99BA20F3093BB3AC3F3CA0BCA6D65EB8") == null) {
            structurePropFieldMap.put("AnonymousStructure_99BA20F3093BB3AC3F3CA0BCA6D65EB8",new HashMap<String, List<String>>());
        }
         propColumnMap = structurePropFieldMap.get("AnonymousStructure_99BA20F3093BB3AC3F3CA0BCA6D65EB8");
        if (propColumnMap.get("updatedTime") == null){
            propColumnMap.put("updatedTime", new ArrayList<>());
            }
            propColumnMap.get("updatedTime").add("lCAPRole.updatedTime");
            propColumnMap.get("updatedTime").add("lCAPUserRoleMapping.updatedTime");
        if (propColumnMap.get("updatedBy") == null){
            propColumnMap.put("updatedBy", new ArrayList<>());
            }
            propColumnMap.get("updatedBy").add("lCAPRole.updatedBy");
            propColumnMap.get("updatedBy").add("lCAPUserRoleMapping.updatedBy");
        if (propColumnMap.get("roleId") == null){
            propColumnMap.put("roleId", new ArrayList<>());
            }
            propColumnMap.get("roleId").add("lCAPUserRoleMapping.roleId");
        if (propColumnMap.get("editable") == null){
            propColumnMap.put("editable", new ArrayList<>());
            }
            propColumnMap.get("editable").add("lCAPRole.editable");
        if (propColumnMap.get("description") == null){
            propColumnMap.put("description", new ArrayList<>());
            }
            propColumnMap.get("description").add("lCAPRole.description");
        if (propColumnMap.get("source") == null){
            propColumnMap.put("source", new ArrayList<>());
            }
            propColumnMap.get("source").add("lCAPUserRoleMapping.source");
        if (propColumnMap.get("userName") == null){
            propColumnMap.put("userName", new ArrayList<>());
            }
            propColumnMap.get("userName").add("lCAPUserRoleMapping.userName");
        if (propColumnMap.get("userId") == null){
            propColumnMap.put("userId", new ArrayList<>());
            }
            propColumnMap.get("userId").add("lCAPUserRoleMapping.userId");
        if (propColumnMap.get("uuid") == null){
            propColumnMap.put("uuid", new ArrayList<>());
            }
            propColumnMap.get("uuid").add("lCAPRole.uuid");
        if (propColumnMap.get("roleStatus") == null){
            propColumnMap.put("roleStatus", new ArrayList<>());
            }
            propColumnMap.get("roleStatus").add("lCAPRole.roleStatus");
        if (propColumnMap.get("createdBy") == null){
            propColumnMap.put("createdBy", new ArrayList<>());
            }
            propColumnMap.get("createdBy").add("lCAPRole.createdBy");
            propColumnMap.get("createdBy").add("lCAPUserRoleMapping.createdBy");
        if (propColumnMap.get("name") == null){
            propColumnMap.put("name", new ArrayList<>());
            }
            propColumnMap.get("name").add("lCAPRole.name");
        if (propColumnMap.get("createdTime") == null){
            propColumnMap.put("createdTime", new ArrayList<>());
            }
            propColumnMap.get("createdTime").add("lCAPRole.createdTime");
            propColumnMap.get("createdTime").add("lCAPUserRoleMapping.createdTime");
        if (propColumnMap.get("id") == null){
            propColumnMap.put("id", new ArrayList<>());
            }
            propColumnMap.get("id").add("lCAPRole.id");
            propColumnMap.get("id").add("lCAPUserRoleMapping.id");
    }
    private String getTableField(String structureName, String param) {
        if (structurePropFieldMap.get(structureName) == null) {
            return param;
        }
        if (param == null || "".equals(param)) {
            return null;
        }
        Map<String, String> tableColumnMap = structureTableColumnMap.get(structureName);
        Map<String, List<String>> propColumnMap = structurePropFieldMap.get(structureName);
        String[] paramSplit = param.split("\\.");
        if (paramSplit.length == 1) {
            List<String> propList = propColumnMap.get(paramSplit[0]);
            String tableColumn = getTableColumn(propList, tableColumnMap);
            if (tableColumn != null) {
                return tableColumn;
            }
        } else if (tableColumnMap.get(param) != null) {
            return tableColumnMap.get(param);
        }
        throw new HttpCodeException(404, "排序参数{" + param + "}不存在");
    }

    // for sonar check Cognitive Complexity
    private String getTableColumn(List<String> propList, Map<String, String> tableColumnMap) {
        String tableColumn = null;
        if (propList != null) {
            for (String prop : propList) {
                String str = tableColumnMap.get(prop);
                if (str == null || "".equals(str)) {
                    continue;
                }
                if (tableColumn == null) {
                    tableColumn = str;
                } else {
                    tableColumn = str.length() >= tableColumn.length() ? tableColumn : str;
                }
            }
        }

        return tableColumn;
    }

    public  <T> T getObjectTableField(String structureName,T obj,List<String> fieldNames) {
        try {
            T cloneObj = CommonFunctionUtil.clone(obj);
            for (String fieldRef : fieldNames) {
                String[] fieldNameSplit = fieldRef.split("\\.");
                Field field = obj.getClass().getDeclaredField(fieldNameSplit[0]);
                Object fieldObject = cloneObj;
                for (int fieldIndex = 1; fieldIndex < fieldNameSplit.length; fieldIndex++) {
                    fieldObject = field.get(fieldObject);
                    field = field.getType().getDeclaredField(fieldNameSplit[fieldIndex]);
                }
                    field.set(fieldObject, getTableField(structureName, (String) field.get(fieldObject)));
                }
                return cloneObj;
            } catch (Exception e) {
                throw new HttpCodeException("500", e);
            }
    }

}
