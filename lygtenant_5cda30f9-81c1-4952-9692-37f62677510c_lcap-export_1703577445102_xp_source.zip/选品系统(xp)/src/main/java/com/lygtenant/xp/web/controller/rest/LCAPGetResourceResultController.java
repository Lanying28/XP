package com.lygtenant.xp.web.controller.rest;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate LCAPGetResourceResultController logic
*
* @author sys
*/
@RestController
public class LCAPGetResourceResultController {

@Autowired private LCAPGetUserResourcesCustomizeService lCAPGetUserResourcesCustomizeService;

@GetMapping("/rest/getUserResources")
public List<LCAPGetResourceResultStructure> LCAPGetResourceResult(@RequestParam(required = true) String userId) throws Exception {
 return lCAPGetUserResourcesCustomizeService.lCAPGetUserResources(userId);
}
}
