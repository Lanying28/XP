/**
 * enumeration objects.
 */
package com.lygtenant.xp.domain.structure;
