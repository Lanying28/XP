package com.lygtenant.xp.web.controller.entities;

import java.io.Serializable;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.math.BigDecimal;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.*;

import com.lygtenant.xp.exception.HttpCodeException;
import com.lygtenant.xp.domain.entities.LCAPPermission;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.entities.LCAPPermissionService;
import com.lygtenant.xp.web.ApiReturn;
import com.lygtenant.xp.service.dto.filters.EntityFilter;
import com.lygtenant.xp.service.dto.filters.AbstractQueryFilter;
import com.lygtenant.xp.service.dto.filters.FilterWrapper;
import com.lygtenant.xp.domain.PageOf;
import com.lygtenant.xp.util.JacksonUtils;
import com.lygtenant.xp.web.validation.*;

/**
* auto generate LCAPPermission controller
*
* @author sys
*/
@RestController
public class LCAPPermissionController {
    @Resource
    private LCAPPermissionService service;

    /**
    * auto gen create method
    **/
    @Validation(value = {
        @ValidationRuleGroup(
                value = "e87a6504a6e44c53b22d492f09dc1760",
                rules = {
                }
        ),
    })
    @PostMapping("/api/l-c-a-p-permission")
    public ApiReturn<LCAPPermission> create(@RequestBody LCAPPermission body) {
        return ApiReturn.of(service.create(body));
    }








    /**
    * auto gen import method
    **/
    @PostMapping("/api/l-c-a-p-permission/import")
    public ApiReturn<String> importEntities(@RequestParam("file") MultipartFile file) {
        return ApiReturn.of(service.importFile(file));
    }



}