package com.lygtenant.xp.repository.entities;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.math.BigDecimal;
import java.math.BigDecimal;
import com.lygtenant.xp.domain.entities.ProSpecificationEntity;
import com.lygtenant.xp.repository.ReferenceHandleMapper;
import com.lygtenant.xp.service.dto.filters.AbstractQueryFilter;
import org.apache.ibatis.annotations.Param;
/**
* auto generate ProSpecificationEntity Mapper
*
* @author sys
*/
public interface ProSpecificationEntityMapper extends ReferenceHandleMapper {

    int insert(ProSpecificationEntity bean);
    int batchInsert(List<ProSpecificationEntity> beans);
    List<ProSpecificationEntity> selectList(@Param("filter") AbstractQueryFilter filter);
    int count(@Param("filter") AbstractQueryFilter filter);

    int update(ProSpecificationEntity bean, List<String> updateFields);
    int batchUpdate(List<ProSpecificationEntity> beans, List<String> updateFields);
    int delete(Long id);
    int batchDelete(List<Long> ids);
    ProSpecificationEntity selectOne(Long id);

    int createOrUpdate(ProSpecificationEntity bean);
    int updateBy(ProSpecificationEntity bean, List<String> updateFields, AbstractQueryFilter filter);
    int deleteBy(@Param("filter") AbstractQueryFilter filter);

}