package com.lygtenant.xp.web.controller.logics;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.web.validation.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.web.controller.logics.dto.*;

/**
* auto generate LCAPGetRoleBindUserListCustomizeController logic
*
* @author sys
*/
@RestController
public class LCAPGetRoleBindUserListCustomizeController {

@Autowired private LCAPGetRoleBindUserListCustomizeService lCAPGetRoleBindUserListCustomizeService;

@Validation(value = {
    @ValidationRuleGroup(
            value = "b52127a8a3924adbbde249442fac8983",
            rules = {
            }
    ),
})
@PostMapping("/api/lcplogics/LCAPGetRoleBindUserList")
public ApiReturn<List<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_E69C6A05AFC359D00B28F67D0E02C8E5>> lCAPGetRoleBindUserList(@RequestBody LCAPGetRoleBindUserListCustomizeControllerDto body) throws Exception {
 return ApiReturn.of(lCAPGetRoleBindUserListCustomizeService.lCAPGetRoleBindUserList(body.getInputRoleId()));
}
}
