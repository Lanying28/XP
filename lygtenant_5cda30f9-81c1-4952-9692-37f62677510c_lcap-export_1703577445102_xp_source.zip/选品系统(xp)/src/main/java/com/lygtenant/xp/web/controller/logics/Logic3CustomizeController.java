package com.lygtenant.xp.web.controller.logics;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.web.validation.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate Logic3CustomizeController logic
*
* @author sys
*/
@RestController
public class Logic3CustomizeController {

@Autowired private Logic3CustomizeService logic3CustomizeService;

@Validation(value = {
    @ValidationRuleGroup(
            value = "d941a1ae935440279f35660270ed027f",
            rules = {
            }
    ),
})
@PostMapping("/api/lcplogics/logic3")
public ApiReturn<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_696132E2866BB3A7304ADB01F51B02DD> logic3() throws Exception {
 return ApiReturn.of(logic3CustomizeService.logic3());
}
}
