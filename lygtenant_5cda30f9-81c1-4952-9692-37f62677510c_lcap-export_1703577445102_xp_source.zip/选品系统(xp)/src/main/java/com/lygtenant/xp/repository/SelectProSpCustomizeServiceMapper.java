package com.lygtenant.xp.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.web.interceptor.annotation.*;
import com.lygtenant.xp.datasource.dynamic.DataSource;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;

import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.domain.entities.*;

/**
* auto generate SelectProSpCustomizeService Mapper
*
* @author sys
*/
public interface SelectProSpCustomizeServiceMapper {

List<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_FC014CDE6D211DB28BBEE65F04FC9784> getAnonymousStructure_4C7C4DCC8008CBC96C0AA0A59669FD8A(@Param("proCode") String proCode);
Long countAnonymousStructure_4C7C4DCC8008CBC96C0AA0A59669FD8A(@Param("proCode") String proCode);

}
