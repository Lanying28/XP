package com.lygtenant.xp.web.controller.logics;

import com.lygtenant.xp.util.*;
import com.lygtenant.xp.context.UserContext;
import com.lygtenant.xp.domain.*;
import com.lygtenant.xp.domain.enumeration.*;
import com.lygtenant.xp.service.*;
import com.lygtenant.xp.service.logics.*;
import com.lygtenant.xp.web.validation.*;
import com.lygtenant.xp.repository.*;
import com.lygtenant.xp.web.ApiReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.time.LocalTime;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import com.lygtenant.xp.domain.structure.*;
import com.lygtenant.xp.service.entities.*;
import com.lygtenant.xp.domain.entities.*;
import com.lygtenant.xp.web.controller.logics.dto.*;

/**
* auto generate Logic4CustomizeController logic
*
* @author sys
*/
@RestController
public class Logic4CustomizeController {

@Autowired private Logic4CustomizeService logic4CustomizeService;

@Validation(value = {
    @ValidationRuleGroup(
            value = "a4c2ea58-f080-4cac-a480-4e4913d831bc",
            rules = {
            }
    ),
    @ValidationRuleGroup(
            value = "f07e2e80-1813-4b54-a178-6983c7c597b8",
            rules = {
            }
    ),
})
@PostMapping("/api/lcplogics/logic4")
public ApiReturn<com.lygtenant.xp.domain.structure.anonymous.AnonymousStructure_D973E5D521E557621AB6C7C329CD488F> logic4(@RequestBody Logic4CustomizeControllerDto body) throws Exception {
 return ApiReturn.of(logic4CustomizeService.logic4(body.getProCode()));
}
}
